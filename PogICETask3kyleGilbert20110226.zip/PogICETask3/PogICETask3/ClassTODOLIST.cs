﻿//kyle gilbert
//20110226
//2021/05/03









using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;

namespace PogICETask3
{
    class ClassTODOLIST
    {

        string text;
        string task;
        string description;
        string date;
        string priority;
        String path = "C:/Users/kyleg/Downloads/PogICETask3updated/PogICETask3/PogICETask3/Todolist.txt";
        public ClassTODOLIST(string task, string description, string date, string priority)
        {
            this.Task = task;
            this.Description = description;
            this.Date = date;
            this.Priority = priority;
        }

        public ClassTODOLIST(string text)
        {
            this.Text = text;
        }

        public string Task { get => task; set => task = value; }
        public string Description { get => description; set => description = value; }
        public string Date { get => date; set => date = value; }
        public string Priority { get => priority; set => priority = value; }
        public string Text { get => text; set => text = value; }

        public void write()
            {
            string ln="";
            
            try
            {   int i= 0;
                using (StreamReader ss = new StreamReader(path))
                {

                    if (i == 0)
                    { 
                    ln =File.ReadAllText(path);
                    }
                    else { 
                    ln =ln+"\n"+ File.ReadAllText(path);}



                }



                using (StreamWriter sr = new StreamWriter(path))
                {
                    string text = task+"#"+ description + "#" + date + "#" + priority+"$";
                   
                    sr.WriteLine(ln+text);
                }

            }
            catch { }

        }

        public string getItem() 
        {
            string ln = "";
            int i = 0;

            try
            {

                using (StreamReader ss = new StreamReader(path))
                {
                    if (i == 0)
                    {
                        ln = File.ReadAllText(path) ;
                    }
                    else
                    {
                        ln = ln + File.ReadAllText(path) ;
                    }


                    
                }
            }
            catch { }

            return (ln);
        }


        public string remove(string search)
        {
                string ln = "",final="";
            string find = "";
                try
                {
                    int i = 0;
                    using (StreamReader ss = new StreamReader(path))
                    {
                        if (i == 0) { ln = File.ReadAllText(path); }
                        else { ln = ln + "\n" + File.ReadAllText(path); }

                        string text = task + "#" + description + "#" + date + "#" + priority + "$";
                    
                    }

                string[] lines = File.ReadAllText(path).Split('$');
                int k = 0;
                foreach (string sentence in lines)
                {
                    if (sentence == search) 
                    { }
                    else
                    {
                        if (k == 0) {
                            //if (sentence!=" "|| sentence != "") { }
                            
                            
                            final=sentence+"$"; }
                        else {
                            final="\n"+final+sentence + "$" ; }
                        k++;
                    }

                }
                ln= final.Substring(0,final.Length-1).Trim('\n') ;




                    //MessageBox.Show("--------------------------------"+File.ReadAllText(path));
                    

                using (StreamWriter sr = new StreamWriter(path))
                    {
                        MessageBox.Show(ln + text);
                        sr.WriteLine(ln + text);
                    }

                }
                catch { }
            return ln;
        }
    }
}
