﻿//kyle gilbert
//20110226
//2021/05/03



using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PogICETask3
{
    public partial class Todolist : Form
    {
        string text1 = "";
        string text3 = "";

        ArrayList arlist1 = new ArrayList();
        ArrayList arlist2 = new ArrayList();

        public Todolist()
        {
            InitializeComponent();
        }

        Add s = new Add();
        ClassTODOLIST r= new ClassTODOLIST("");
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            s.ShowDialog();
            this.Close();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            text3 = listBoxTodolist.Items[listBoxTodolist.SelectedIndex].ToString();
            //MessageBox.Show(""+text3);
        }

        private void Todolist_Load(object sender, EventArgs e)
        {   
            int ct = 0;
            string text1=r.getItem();
            string text2="";
            string []lines =text1.Split('$');

            foreach (string sentence in lines)
            {
                string[] words = lines[ct].Split('#');
                arlist1.Add(sentence);
                int n = 0;
                foreach (string word in words) 
                    {

                    text2 =text2 + word + "\t";

                    if (n == 4){
                        text2 = "";
                    }
                    else{n++;}
                    
                        n = 0;
                    }
                listBoxTodolist.Items.Add(text2);
                arlist2.Add(text2);
                text2 = "";
                ct++;
            }



           
           
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            string search = "";
            //string []text2 =;
            for (int i = 0; i < arlist1.Count; i++)
            {
                //string arrayItem = string.Format($"Name  is {arlist[i]}");
                //MessageBox.Show((string)arlist1[i] + "\n" + (string)arlist2[i]);
                if ((string)arlist2[i] == text3) { search = (string)arlist1[i]; }
                if (search!="") { i = arlist1.Count;
                    //MessageBox.Show(search);
                
                }
            }


        }
    }
}
