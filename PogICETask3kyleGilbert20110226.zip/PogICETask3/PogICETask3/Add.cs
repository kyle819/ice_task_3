﻿//kyle gilbert
//20110226
//2021/05/03


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PogICETask3
{
    public partial class Add : Form
    {
        public Add()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string task=txbTask.Text;
            string description = txbDesc.Text;
            string priority = txbPriority1.Text;

            string date = dateTimePicker1.Value.ToString("yyyy-MM-dd");


            MessageBox.Show("\n"+ task
            +"\n"+ description
            +"\n"+ priority
            +"\n"+ date);

            ClassTODOLIST a = new ClassTODOLIST(task, description, priority, date);
            a.write();








            this.Hide();
            Todolist s = new Todolist();
            s.ShowDialog();
            this.Close();

        }
    }
}
